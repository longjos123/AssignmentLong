;

<?php $__env->startSection('content'); ?>
    <h1 style="font-family: 'Rubik', sans-serif; font-size: 30px;" >Quản lí tour</h1>
    <table class="table mb-0">
        <thead>
        <tr>
            <th>#</th>
            <th>Avatar</th>
            <th>Tên tour</th>
            <th>Số ngày đi</th>
            <th>Miêu tả</th>
            <th>Phương tiện</th>
            <th>Quốc gia</th>
            <th>Giá/người</th>
            <th>
                <a class="btn btn-primary" style="width: 105px;" data-toggle="modal" data-target="#myModal">Thêm</a>
            </th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td>
                    <div class="round-img">
                        <a href=""><img width="200" src="<?php echo e(asset( 'storage/' . $tour->image)); ?>" style=""></a>
                    </div>
                </td>
                <td><?php echo e($tour->name); ?></td>
                <td><span><?php echo e($tour->num_day); ?></span></td>
                <td  style="width: 300px;cursor:pointer}" ><a data-toggle="modal" data-target="#myModal1" onclick="detail(<?php echo e($tour->id); ?>)">Xem chi tiết</a></td>
                <td><?php echo e($tour->tourTransport->name); ?></td>
                <td><?php echo e($tour->tourCountries->name); ?></td>
                <td><span style="font-size: 15px;" class="badge badge-success">$<?php echo e($tour->price); ?></span></td>
                <td>
                        <a href="<?php echo e(route('tour.edit',['id' => $tour->id])); ?>"
                           class="btn btn-success"><i class="fas fa-edit"></i>
                        </a>
                        <a class="btn btn-danger"
                           href="<?php echo e(route('tour.delete',['id' => $tour->id])); ?>"
                           onclick="return confirm('Xác nhận xóa?');"><i class="far fa-trash-alt"></i>
                        </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Thêm tour</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="<?php echo e(route('tour.add')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="">Tên tour</label>
                                    <input name="name" style="" type="text" class="form-control">
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="">Phương tiện</label>
                                            <select name="transport_id" style="" class="form-control">
                                                <option>--Phương tiện--</option>
                                                <?php $__currentLoopData = $transports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($transport->id); ?>"><?php echo e($transport->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="">Quốc gia</label>
                                            <select name="countries_id" style="" class="form-control">
                                                <option>--Quốc gia--</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="">Số ngày</label>
                                            <input name="num_day"  type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="">Giá</label>
                                            <input name="price" style="" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="">Ảnh</label>
                                    <input name="image" style="" type="file" class="form-control">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="">Miêu tả</label>
                                    <textarea id="editor1" name="description" style="height: 296px;" type="text" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>

                        <button
                            onclick="return confirm('Xác nhận thêm!!!');"
                            class="btn btn-success" type="submit"
                            style="width: 765px;margin-left: 16px;"
                        >Lưu
                        </button>
                    </form>

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="myModal1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Chi tiết tour</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body" id="des">

                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<script>
    function detail(id) {
        $.get('<?php echo e(route('tour.detailDescription')); ?>', {"id": id}, function (tour){

            // console.log(tour.name);
            
            document.getElementById('des').innerHTML = tour.description;
        });
    }
</script>



<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/admin/tour/index.blade.php ENDPATH**/ ?>