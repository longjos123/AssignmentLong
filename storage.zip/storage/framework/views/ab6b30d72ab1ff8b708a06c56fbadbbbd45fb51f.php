<div class="recent_trip_area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section_title text-center mb_70">
                    <h3>Bài viết</h3>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="single_trip">
                        <div class="thumb">
                            <img height="233px" src="<?php echo e(asset('storage/'. $new->image)); ?>" alt="">
                        </div>
                        <div class="info">
                            <div class="date">
                                <span><?php echo e($new->created_at); ?></span>
                            </div>
                            <a href="<?php echo e(route('blog.detail',['id' => $new->id])); ?>">
                                <h3><?php echo e($new->title); ?></h3>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/home/recent_trip_area.blade.php ENDPATH**/ ?>