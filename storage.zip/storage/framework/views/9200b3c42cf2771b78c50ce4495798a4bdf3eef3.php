<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    <div class="single-post">
                        <div class="feature-img">
                            <img width="730" height="365" class="img-fluid" src="<?php echo e(asset('storage/'.$blog->image)); ?>" alt="">
                        </div>
                        <div class="blog_details">
                            <h2><?php echo e($blog->title); ?></h2>
                            <ul class="blog-info-link mt-3 mb-4">
                                <li><a href="#"><i class="fa fa-user"></i> Du lịch, Đời sống</a></li>
                                <li><a href="#"><i class="fa fa-comments"></i> 03 bình luận</a></li>
                            </ul>
                           <?php echo $blog->content; ?>

                        </div>
                    </div>

                    <nav class="blog-pagination justify-content-center d-flex">
                        <ul class="pagination">
                            <li class="page-item">
                                <a href="#" class="page-link" aria-label="Previous">
                                    <i class="ti-angle-left"></i>
                                </a>
                            </li>
                            <li class="page-item">
                                <a href="#" class="page-link">1</a>
                            </li>
                            <li class="page-item active">
                                <a href="#" class="page-link">2</a>
                            </li>
                            <li class="page-item">
                                <a href="#" class="page-link" aria-label="Next">
                                    <i class="ti-angle-right"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="blog_right_sidebar">
                    <aside class="single_sidebar_widget search_widget">
                        <form method="post" action="<?php echo e(route('find_news')); ?>}" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-group mb-3">
                                    <input <?php if(isset($searchData['title'])): ?> value="<?php echo e($searchData['title']); ?>" <?php endif; ?> name="title" type="text" class="form-control" placeholder='Search Keyword'
                                           onfocus="this.placeholder = ''"
                                           onblur="this.placeholder = 'Search Keyword'">
                                    <div class="input-group-append">
                                        <button class="btn" type="button"><i class="ti-search"></i></button>
                                    </div>
                                </div>
                            </div>
                            <button class="button rounded-0 primary-bg text-white w-100 btn_1 boxed-btn"
                                    type="submit">Search</button>
                        </form>
                    </aside>

                    <aside class="single_sidebar_widget popular_post_widget">
                        <h3 class="widget_title">Bài đăng gần đây</h3>
                        <?php $__currentLoopData = $blogLimits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogLimit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media post_item">
                                <img width="80" height="80" src="<?php echo e(asset('storage/'.$blogLimit->image)); ?>" alt="post">
                                <div class="media-body">
                                    <a href="single-blog.html">
                                        <h3><?php echo e($blogLimit->title); ?></h3>
                                    </a>
                                    <p><?php echo e($blogLimit->created_at); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </aside>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/blog_detail/blog_area single-post-area section-padding.blade.php ENDPATH**/ ?>