<div class="popular_places_area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section_title text-center mb_70">
                    <h3>More Places</h3>
                </div>
            </div>
        </div>
        <div class="row">
           <?php $__currentLoopData = $tourLimits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tourLimit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="single_place">
                        <div class="thumb">
                            <img height="233px" src="<?php echo e(asset('storage/'.$tourLimit->image)); ?>" alt="">
                            <a href="#" class="prise">$<?php echo e($tourLimit->price); ?></a>
                        </div>
                        <div class="place_info">
                            <a href="<?php echo e(route('tour_detail',['id' => $tourLimit->id])); ?>"><h3><?php echo e($tourLimit->name); ?></h3></a>
                            <p><?php echo e($tourLimit->tourCountries->name); ?></p>
                            <div class="rating_days d-flex justify-content-between">
                                <span class="d-flex justify-content-center align-items-center">
                                     <i class="fa fa-star"></i>
                                     <i class="fa fa-star"></i>
                                     <i class="fa fa-star"></i>
                                     <i class="fa fa-star"></i>
                                     <i class="fa fa-star"></i>
                                     <a href="#">(20 Review)</a>
                                </span>
                                <div class="days">
                                    <i class="fa fa-clock-o"></i>
                                    <a href="#"><?php echo e($tourLimit->num_day); ?> Days</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/tour_detail/popular_places_area.blade.php ENDPATH**/ ?>