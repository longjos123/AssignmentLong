<div style="margin-bottom: 300px; margin-top: 30px" class="container">
    <div class="row">
        <table class="table mb-0">
            <thead>
            <tr>
                <th>#</th>
                <th>Người đặt</th>
                <th>Tour</th>
                <th>Số người</th>
                <th>Khách sạn</th>
                <th>Giá tổng</th>
                <th>Ngày bắt đầu</th>
                <th>Ngày kết thúc</th>
                <th style="width: 110px;">Trạng thái</th>
                <th>Hành động</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $userTours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $userTour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($userTour->name); ?></td>
                    <td><span><?php echo e($userTour->tour->name); ?></span></td>
                    <td><span><?php echo e($userTour->num_people); ?></span></td>
                    <td><?php echo e(empty($userTour->hotel->name)?'_':$userTour->hotel->name); ?></td>
                    <td><span style="font-size: 15px;" class="badge badge-success">$<?php echo e(($userTour->tour->price)*($userTour->num_people)); ?></span></td>
                    <td><?php echo e($userTour->start_date); ?></td>
                    <td><?php echo e($userTour->end_date); ?></td>
                    <td style="color: <?php echo e(($userTour->status) == 0? '#c13a6b':'green'); ?>">
                        <?php if($userTour->confirm_tour == 1): ?>
                            <?php echo e(($userTour->status) == 0?'Đang xử lí':'Đã duyệt'); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($userTour->confirm_tour == 0): ?>
                            <a class="btn btn-primary" href="<?php echo e(route('confirm_tour',['id'=>$userTour->id])); ?>">Đặt tour</a>
                        <?php endif; ?>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/booking_tour/cart_tour.blade.php ENDPATH**/ ?>