<!-- <link rel="manifest" href="site.webmanifest"> -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('client-theme/img/favicon.png')); ?>">
<!-- Place favicon.ico in the root directory -->

<!-- CSS here -->
    <link rel="stylesheet" href="<?php echo e(asset('client-theme/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/magnific-popup.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/themify-icons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/nice-select.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/flaticon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/gijgo.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/slick.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/slicknav.css')); ?>">
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">


<link rel="stylesheet" href="<?php echo e(asset('client-theme/css/style.css')); ?>">
<!-- <link rel="stylesheet" href="<?php echo e(asset('client-theme/css/responsive.css')); ?>"> -->



<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/layouts/style.blade.php ENDPATH**/ ?>