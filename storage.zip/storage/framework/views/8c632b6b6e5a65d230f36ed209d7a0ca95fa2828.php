<div class="popular_places_area">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="filter_result_wrap">
                    <h3>Lọc</h3>
                    <div class="filter_bordered">
                        <form action="<?php echo e(route('filter_tour')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="filter_inner">
                                <div class="row">
                                    <div class="col-lg-12" style="margin-bottom: 10px">
                                        <label>Tên tour</label>
                                        <div class="single_select">
                                            <input <?php if(isset($searchData['name_tour'])): ?> value="<?php echo e($searchData['name_tour']); ?>" <?php endif; ?> name="name_tour" class="form-control" placeholder="Tên">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <label>Quốc gia</label>
                                        <select name="countries_id" style="" class="form-control">
                                            <option value="">--Quốc gia--</option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(isset($searchData['countries_id']) && $country->id == $searchData['countries_id']): ?> selected <?php endif; ?> value="<?php echo e($country->id); ?>">
                                                    <?php echo e($country->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="range_slider_wrap">
                                            <label>Giá</label>
                                            <div class="row">
                                                <div class="col-6">
                                                    <input <?php if(isset($searchData['price_min'])): ?> value="<?php echo e($searchData['price_min']); ?>" <?php endif; ?> name="price_min" type="text" class="form-control">
                                                </div>
                                                <div class="col-6">
                                                    <input <?php if(isset($searchData['price_max'])): ?> value="<?php echo e($searchData['price_max']); ?>" <?php endif; ?> name="price_max" type="text" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="reset_btn" style="margin-top: 30px">
                                <button class="boxed-btn4" type="submit">Lọc</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-8" id="show_tour">
                <div class="row">
                    <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 col-md-6">
                            <div class="single_place">
                                <div class="thumb">
                                    <img href="" height="233" src="<?php echo e(asset('storage/' .$tour->image)); ?>" alt="">
                                    <a href="#" class="prise">$<?php echo e($tour->price); ?></a>
                                </div>
                                <div class="place_info">
                                    <a href="<?php echo e(route('tour_detail',['id' => $tour->id])); ?>"><h3><?php echo e($tour->name); ?></h3></a>
                                    <p><?php echo e($tour->tourCountries->name); ?></p>
                                    <div class="rating_days d-flex justify-content-between">
                                        <span class="d-flex justify-content-center align-items-center">
                                             <i class="fa fa-star"></i>
                                             <i class="fa fa-star"></i>
                                             <i class="fa fa-star"></i>
                                             <i class="fa fa-star"></i>
                                             <i class="fa fa-star"></i>
                                             <a href="#">(20 Review)</a>
                                        </span>
                                        <div class="days">
                                            <i class="fa fa-clock-o"></i>
                                            <a href="#"><?php echo e($tour->num_day); ?> Days</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="more_place_btn text-center">
                            <?php echo e($tours->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function (){
        $('#name_tour').keyup(function (){
            var name = $(this).val();
        })
    })
</script>
<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/tour/popular_places_area.blade.php ENDPATH**/ ?>