;

<?php $__env->startSection('content'); ?>
    <h1 style="font-family: 'Rubik', sans-serif; font-size: 30px;" >Tour đã đặt</h1>
    <table class="table mb-0">
        <thead>
        <tr>
            <th>#</th>
            <th>Avatar</th>
            <th>Tên</th>
            <th>Tour</th>
            <th>Số người</th>
            <th>Khách sạn</th>
            <th>Giá tổng</th>
            <th>Ngày bắt đầu</th>
            <th>Ngày kết thúc</th>
            <th>Trạng thái</th>
            <th>
                <a class="btn btn-primary" style="width: 105px;" data-toggle="modal" data-target="#myModal">Thêm</a>
            </th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $userTours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $userTour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td>
                    <div class="round-img">
                        <a href=""><img width="40" src="<?php echo e(asset('storage/'.$userTour->user->avatar_url)); ?>" style=""></a>
                    </div>
                </td>
                <td><?php echo e($userTour->user->fullname); ?></td>
                <td><span><?php echo e($userTour->tour->name); ?></span></td>
                <td><span><?php echo e($userTour->num_people); ?></span></td>
                <td><?php echo e(empty($userTour->hotel->name)?'_':$userTour->hotel->name); ?></td>
                <td><span style="font-size: 15px;" class="badge badge-success">$<?php echo e(($userTour->tour->price)*($userTour->num_people)); ?></span></td>
                <td><?php echo e($userTour->start_date); ?></td>
                <td><?php echo e($userTour->end_date); ?></td>

                <td style="color: <?php echo e(($userTour->status) == 0? '#c13a6b':'green'); ?>">
                    <?php if($userTour->confirm_tour == 1): ?>
                        <?php echo e(($userTour->status) == 0?'Đang xử lí':'Đã duyệt'); ?>

                    <?php else: ?>
                        Đang xử lí
                    <?php endif; ?>
                </td>
                <td>
                    <a class="btn btn-success" href="<?php echo e(route('edit-booked-tour',['id' => $userTour->id])); ?>"><i class="fas fa-edit"></i></a>
                    <a class="btn btn-danger"
                       href="<?php echo e(route('delete-booked',['id' => $userTour->id])); ?>"
                       onclick="return confirm('Xác nhận xóa?');"><i class="far fa-trash-alt"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Đặt tour</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="<?php echo e(route('tour_user.add')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Tên Tour</label>
                                <select name="tour_id" style="" class="form-control">
                                    <option>--Tour--</option>
                                    <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tour->id); ?>"><?php echo e($tour->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Người đặt</label>
                                <select name="user_id" style="" class="form-control">
                                    <option>--Nguời đặt--</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->fullname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="row" style="">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="">Số điện thoại</label>
                                        <input name="phone_number"  type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="">Số người</label>
                                        <input name="num_people" style="" type="text" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="">Khách sạn</label>
                                <select name="hotel_id" style="" class="form-control">
                                    <option>--Chọn khách sạn--</option>
                                    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($hotel->id); ?>"><?php echo e($hotel->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Ngày khởi hành</label>
                                <input name="start_date" style="" type="date" class="form-control">
                            </div>
                        </div>
                        <button
                            onclick="return confirm('Xác nhận thêm!!!');"
                            class="btn btn-success" type="submit"
                            style="width: 765px;margin-left: 16px;"
                        >Lưu
                        </button>
                    </form>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/admin/user_tour/index.blade.php ENDPATH**/ ?>