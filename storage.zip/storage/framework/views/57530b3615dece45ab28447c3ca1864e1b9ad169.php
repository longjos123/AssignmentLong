<div class="bradcam_area bradcam_bg_4">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="bradcam_text text-center">
                    <h3>Liên hệ</h3>
                    <p>Pixel perfect design with awesome contents</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/contact/bradcam_area bradcam_bg_4.blade.php ENDPATH**/ ?>