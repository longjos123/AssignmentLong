;

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-6">
            <h1 style="font-family: 'Rubik', sans-serif; font-size: 30px;" >Quản lí phương tiện</h1>
            <table class="table mb-0">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Tên</th>
                    <th>
                        <a  class="btn btn-primary" style="width: 105px;" data-toggle="modal" data-target="#myModal">Thêm</a>
                    </th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $transports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($transport->id); ?></td>
                        <td><?php echo e($transport->name); ?></td>
                        <td>
                            <a class="btn btn-success" href="<?php echo e(route('edit-transport',['id' => $transport->id])); ?>">Sửa</a>
                            <a class="btn btn-danger"
                               href="<?php echo e(route('delete-transport',['id' => $transport->id])); ?>"
                               onclick="return confirm('Xác nhận xóa?');">Xóa
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Thêm phương tiện</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form action="<?php echo e(route('transport.add')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Tên phương tiện</label>
                            <input name="name" style="" type="text" class="form-control">
                        </div>
                        <button style="width:265px;"
                                onclick="return confirm('Xác nhận thêm!!!');"
                                class="btn btn-success"
                                type="submit">Lưu
                        </button>
                    </form>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/admin/transport/index.blade.php ENDPATH**/ ?>