;

<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-left: 10px">
        <h1 style="font-family: 'Rubik', sans-serif; font-size: 30px;" >Sửa tour đã đặt</h1>
        <div class="row">
            <form method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col-6">
                    <div class="form-group">
                        <label for="">Tên Tour</label>
                        <input style="width: 500px" type="text" class="form-control" value="<?php echo e($userTour->tour->name); ?>" disabled>
                    </div>
                    <div class="form-group">
                        <label for="">Người đặt</label>
                        <input style="width: 500px" type="text" class="form-control" value="<?php echo e($userTour->user->fullname); ?>" disabled>
                    </div>

                    <div class="row" style="width: 500px">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="">Số điện thoại</label>
                                <input name="phone_number"  type="text" class="form-control" value="<?php echo e($userTour->phone_number); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="">Số người</label>
                                <input name="num_people" style="width: 245px" type="text" class="form-control" value="<?php echo e($userTour->num_people); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="">Khách sạn</label>
                        <select name="hotel_id" style="width: 500px" class="form-control">
                            <option value="<?php echo e(empty($userTour->hotel->id)?'':$userTour->hotel->id); ?>"><?php echo e(empty($userTour->hotel->name)?'_':$userTour->hotel->name); ?></option>
                            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($hotel->id); ?>"><?php echo e($hotel->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Ngày khởi hành</label>
                        <input name="start_date" style="width: 500px" type="date" class="form-control" value="<?php echo e($userTour->start_date); ?>">
                    </div>
                    <div class="form-group">
                        <label>Trạng thái</label>
                        <select name="status" style="width: 500px" class="form-control">
                            <option value="0" style="color: #c13a6b">Đang xử lí</option>
                            <option value="1" style="color: green">Duyệt</option>
                        </select>
                    </div>
                </div>
                <button
                    onclick="return confirm('Xác nhận thay đổi!!!');"
                    class="btn btn-success" type="submit"
                    style="margin-left: 9px;width: 500px;margin-top: 30px;">Lưu
                </button>
                <br>
                <a style="margin-left: 9px;width: 500px;margin-top: 30px;" class="btn btn-danger" href="<?php echo e(route('tour_user.index')); ?>">Hủy</a>
            </form>
            <div class="col-6">
                <div class="img-tour" >
                    <img style="border-radius: 10px; width: 675px;height: 290px;margin-left: 15px " src="<?php echo e(asset('storage/'.$userTour->tour->image)); ?>">
                </div>
                <div class="detail-tour" style="margin-left: 15px;margin-top: 15px">
                    <label for="">Chi tiết</label><br>
                    <span>
                        Chi tiết tour <?php echo e($userTour->tour->name); ?>

                    </span>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/admin/user_tour/edit.blade.php ENDPATH**/ ?>