<!-- JS here -->
<script src="<?php echo e(asset('client-theme/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/ajax-form.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/scrollIt.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/jquery.scrollUp.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/jquery.slicknav.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/gijgo.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/slick.min.js')); ?>"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>



<!--contact js-->
<script src="<?php echo e(asset('client-theme/js/contact.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/jquery.form.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('client-theme/js/mail-script.js')); ?>"></script>


<script src="<?php echo e(asset('client-theme/js/main.js')); ?>"></script>
<script>
    $('#datepicker').datepicker({
        iconsLibrary: 'fontawesome',
        icons: {
            rightIcon: '<span class="fa fa-caret-down"></span>'
        }
    });
</script>
<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/layouts/script.blade.php ENDPATH**/ ?>