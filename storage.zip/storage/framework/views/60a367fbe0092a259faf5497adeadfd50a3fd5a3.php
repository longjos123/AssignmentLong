<div class="destination_banner_wrap overlay">
    <div class="destination_text text-center">
        <h3><?php echo e($tour->name); ?></h3>
        <p>Pixel perfect design with awesome contents</p>
    </div>
</div>
<?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/client/tour_detail/banner.blade.php ENDPATH**/ ?>