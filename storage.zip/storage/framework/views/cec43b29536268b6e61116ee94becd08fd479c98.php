;

<?php $__env->startSection('content'); ?>
    <h1 style="font-family: 'Rubik', sans-serif; font-size: 30px;" >Sửa bài viết</h1>
    <form action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <form action="" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="">Title</label>
                <input name="title" style="" type="text" class="form-control" value="<?php echo e($news->title); ?>">
            </div>
            <div class="form-group">
                <label for="">Ảnh bài viết</label>
                <input name="image" style="" type="file" class="form-control">
            </div>
            <div class="form-group">
                <label for="">Content</label>
                <textarea id="editor1" name="content" style="" type="text" class="form-control"><?php echo e($news->content); ?></textarea>
            </div>
            <button
                class="btn btn-success" type="submit"
                style="width: 200px;"
            >Lưu
            </button>

        </form>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/admin/news/edit.blade.php ENDPATH**/ ?>