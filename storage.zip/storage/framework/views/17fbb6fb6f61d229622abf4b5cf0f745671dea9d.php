;

<?php $__env->startSection('content'); ?>
    <form action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label for="">Tên tour</label>
                    <input name="name" style="" type="text" class="form-control" value="<?php echo e($tour->name); ?>">
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Phương tiện</label>
                            <select name="transport_id" style="" class="form-control">
                                <option value="<?php echo e($tour->transport_id); ?>"><?php echo e($tour->tourTransport->name); ?></option>
                                <?php $__currentLoopData = $transports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($transport->id); ?>"><?php echo e($transport->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Quốc gia</label>
                            <select name="countries_id" style="" class="form-control">
                                <option value="<?php echo e($tour->countries_id); ?>"><?php echo e($tour->tourCountries->name); ?></option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Số ngày</label>
                            <input name="num_day"  type="text" class="form-control" value="<?php echo e($tour->num_day); ?>">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label for="">Giá</label>
                            <input name="price" style="" type="text" class="form-control" value="<?php echo e($tour->price); ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="">Ảnh</label>
                    <input name="image" style="" type="file" class="form-control">
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label for="">Miêu tả</label>
                    <textarea id="editor1" name="description" style="height: 296px;" type="text" class="form-control" value=""><?php echo e($tour->description); ?></textarea>
                </div>
            </div>
            <button
                class="btn btn-success" type="submit"
                style="margin-left: 9px;width: 100px;"
            >Lưu
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/admin/tour/edit.blade.php ENDPATH**/ ?>