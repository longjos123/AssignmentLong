;

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-6">
            <h1 style="font-family: 'Rubik', sans-serif; font-size: 30px;" >Sửa khách sạn</h1>
            <form method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Tên</label>
                    <input class="form-control" name="name" value="<?php echo e($country->name); ?>">
                </div>
                <button type="submit" class="btn btn-success">Lưu</button>
                <a href="<?php echo e(route('hotel.index')); ?>" class="btn btn-danger">Hủy</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project_Long_Xoe\projectAssg\resources\views/admin/countries/edit.blade.php ENDPATH**/ ?>